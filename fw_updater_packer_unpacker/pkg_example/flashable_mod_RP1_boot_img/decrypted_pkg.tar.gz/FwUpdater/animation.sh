#!/bin/sh

SKU=`rawdata --get_dump=sku_name`

epd_cmd()
{
  epd_fb_test $@ >/dev/null 2>&1
}

while [ 1 ]
do
  for file in `\find $(dirname ${0})/${SKU} -name '*.bmp' | sort`; do
     epd_cmd file GC16 PART $file
     sleep 1
  done
done


exit 0
