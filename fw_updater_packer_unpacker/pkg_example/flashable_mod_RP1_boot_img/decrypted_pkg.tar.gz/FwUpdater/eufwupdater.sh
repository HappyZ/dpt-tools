#!/bin/sh

UPDATER_BASE=$(dirname ${0})
ANIM_PID=0

${UPDATER_BASE}/animation.sh &
ANIM_PID=$!

if [ -x /usr/local/bin/factory_reset.sh ]
then
  factory_reset.sh --no_epd_init
  sleep 1
fi

if [ $ANIM_PID -ne 0 ]
then
  kill $ANIM_PID
fi

exit 2
